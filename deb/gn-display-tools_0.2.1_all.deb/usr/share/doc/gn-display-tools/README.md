# gn-display-tools

Two helpers for recovering from GNOME display problems:

- **gn-fix** — repair GNOME login loops (cleans stale sockets, fixes `/tmp/.X11-unix` perms, restarts GDM, toggles Wayland/Xorg, disable/enable extensions, GPU info).
- **dp-recover** — recover a lost DisplayPort session without logging out (triggers hotplug, asks Mutter to re-apply monitors; optional driver rebind).

## Install
```
sudo dpkg -i gn-display-tools_0.2.1_all.deb
```

## Usage
```
gn-fix
dp-recover --help
```
